import re

name = ("Felipe")
print(name)
name = re.sub(r"F","E", name)
print(name)